<html>
<head>
	<title>Lightweight theme</title>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
</head>
<body>
<div id="wrapper">
	<div id="header">
	</div>

